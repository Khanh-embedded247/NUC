#include <ros/ros.h>
#include <vesc_msgs/VescStateStamped.h>
#include <std_msgs/Int64.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Float64.h>

// 1 == encoder left
ros::Publisher pub1;
ros::Subscriber sub1;
// 2 == encoder right
ros::Publisher pub2;
ros::Subscriber sub2;
// 3 == motor left
ros::Publisher pub3;
ros::Subscriber sub3;

ros::Publisher amp1;
ros::Publisher brake1;
//4 == motor right;
ros::Publisher pub4;
ros::Subscriber sub4;

ros::Publisher amp2;
ros::Publisher brake2;

std_msgs::Int64 encoder1;
std_msgs::Int64 encoder2;

std_msgs::Float64 duty_cycle1;
std_msgs::Float64 duty_cycle2;

std_msgs::Float64 speed1;
std_msgs::Float64 speed2;


void callback1(const vesc_msgs::VescStateStamped::ConstPtr& msg)
{
    speed1.data = msg->state.speed;
    encoder1.data = (int)msg->state.distance_traveled;
    ROS_INFO("Data sent");
    return;
}
void callback2(const vesc_msgs::VescStateStamped::ConstPtr& msg)
{
    speed2.data = msg->state.speed;
    encoder2.data = (int)msg->state.distance_traveled;
    ROS_INFO("Data sent");
    return;
}
void callback3(const std_msgs::Float32::ConstPtr& msg)
{
    duty_cycle1.data = msg->data;
    
    return;
}
void callback4(const std_msgs::Float32::ConstPtr& msg)
{

    duty_cycle2.data = msg->data;

    return;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "vesc_converter");
    ros::NodeHandle n;

    std_msgs::Float64 starting_current;
    starting_current.data = 3;

    std_msgs::Float64 braking_current;
    braking_current.data = 3;

    std_msgs::Float64 normal_current;
    normal_current.data = 1;

    // Encoders
    pub1 = n.advertise<std_msgs::Int64>("/lwheel", 10);
    pub2 = n.advertise<std_msgs::Int64>("/rwheel", 10);

    sub1 = n.subscribe("/left/sensors/core", 10, callback1);
    sub2 = n.subscribe("/right/sensors/core", 10, callback2);

    // Motors
    pub3 = n.advertise<std_msgs::Float64>("/left/commands/motor/duty_cycle", 10);
    pub4 = n.advertise<std_msgs::Float64>("/right/commands/motor/duty_cycle", 10);

    sub3 = n.subscribe("/lmotor_cmd", 10, callback3);
    sub4 = n.subscribe("/rmotor_cmd", 10, callback4);


    /*

    //Amp
    amp1 = n.advertise<std_msgs::Float64>("/left/commands/motor/current", 10);
    amp2 = n.advertise<std_msgs::Float64>("/right/commands/motor/current", 10);
    
    //Brake
    brake1 = n.advertise<std_msgs::Float64>("/left/commands/motor/brake", 10);
    brake2 = n.advertise<std_msgs::Float64>("/right/commands/motor/brake", 10);

    */

    while(ros::ok())
    {
        /*
        pub1.publish(encoder1);
        pub2.publish(encoder2);
        if(speed1.data == 0 && duty_cycle1.data > 0.1 && speed2.data == 0 && duty_cycle2.data > 0.1)
        {
            amp1.publish(starting_current);
            amp2.publish(starting_current);
        }

        else if(duty_cycle1.data == 0 && duty_cycle2.data == 0 && speed1.data > 0 && speed2.data > 0)
        {
            brake1.publish(braking_current);
            brake2.publish(braking_current);
        }
        else
        {
            amp1.publish(normal_current);
            amp2.publish(normal_current);
            pub3.publish(duty_cycle1);
            pub4.publish(duty_cycle2);
        }
        */

        pub1.publish(encoder1);
        pub2.publish(encoder2);
        pub3.publish(duty_cycle1);
        pub4.publish(duty_cycle2);
        ros::spinOnce();
    }
    
    return 0;
}