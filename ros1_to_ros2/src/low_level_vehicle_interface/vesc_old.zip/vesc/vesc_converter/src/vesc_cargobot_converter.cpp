#include <ros/ros.h>
#include <vesc_msgs/VescStateStamped.h>
#include <std_msgs/Int64.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Float64.h>

/* Calib wheel because they dont run at the same speed when receiving the same duty_cycle */
#define RR_MOTOR_CALIB  1.1400
#define SIDEWAY_CALIB   1.1000

/* Convert from velocity command to duty_cycle
 * speed (feedback) 600.0
 * real rpm = 40
 * duty_cycle (command) = 0.1
 * speed = 0.17 * 3.14 * rpm / 60 = 0.0089 * rpm
 * duty_cycle (command) = 0.1 ~ 0.3556 m/s
 * --> duty_cycle = vel * 0.281 
 */

 /* Convert from velocity command to duty_cycle
 * speed (feedback) 
 * real rpm = 9
 * duty_cycle (command) = 0.1
 * speed = 0.17 * 3.14 * rpm / 60 = 0.0089 * rpm
 * duty_cycle (command) = 0.1 ~ 0.08 m/s
 * --> duty_cycle = vel * 0.35
 */

  /* Convert from velocity command to duty_cycle
 * speed (feedback) 
 * real rpm = 12
 * duty_cycle (command) = 0.1
 * speed = 0.17 * 3.14 * rpm / 60 = 0.0089 * rpm
 * duty_cycle (command) = 0.1 ~ 0.1 m/s
 * --> duty_cycle = vel * 0.35
 */

 /*
    1 round : 9s
 */
#define VEL_TO_DUTY     0.35

// encoder front left
ros::Publisher pub_flen;
ros::Subscriber sub_flen;

// encoder front right
ros::Publisher pub_fren;
ros::Subscriber sub_fren;

// encoder rear left
ros::Publisher pub_rlen;
ros::Subscriber sub_rlen;

// encoder rear right
ros::Publisher pub_rren;
ros::Subscriber sub_rren;

/* ------------------------------- Motor-----------------------------------*/
// motor front left
ros::Publisher pub_flmotor;
ros::Subscriber sub_flmotor;

ros::Publisher amp_flmotor;
ros::Publisher brake_flmotor;

// motor front right;
ros::Publisher pub_frmotor;
ros::Subscriber sub_frmotor;

ros::Publisher amp_frmotor;
ros::Publisher brake_frmotor;

// motor rear left
ros::Publisher pub_rlmotor;
ros::Subscriber sub_rlmotor;

ros::Publisher amp_rlmotor;
ros::Publisher brake_rlmotor;

// motor rear right;
ros::Publisher pub_rrmotor;
ros::Subscriber sub_rrmotor;

ros::Publisher amp_rrmotor;
ros::Publisher brake_rrmotor;

/* ------------------------------ Message ------------------------------------*/
std_msgs::Int64 encoder_fl;
std_msgs::Int64 encoder_fr;
std_msgs::Int64 encoder_rl;
std_msgs::Int64 encoder_rr;

std_msgs::Float64 duty_cycle_fl;
std_msgs::Float64 duty_cycle_fr;
std_msgs::Float64 duty_cycle_rl;
std_msgs::Float64 duty_cycle_rr;

std_msgs::Float64 speed_fl;
std_msgs::Float64 speed_fr;
std_msgs::Float64 speed_rl;
std_msgs::Float64 speed_rr;

/* ------------------------------ Encoder callback ------------------------------------*/
void callback_flen(const vesc_msgs::VescStateStamped::ConstPtr& msg)
{
    speed_fl.data = msg->state.speed;
    encoder_fl.data = (int)msg->state.distance_traveled;
    ROS_INFO("Data front left sent");
    return;
}

void callback_fren(const vesc_msgs::VescStateStamped::ConstPtr& msg)
{
    speed_fr.data = msg->state.speed;
    encoder_fr.data = (int)msg->state.distance_traveled;
    ROS_INFO("Data front right sent");
    return;
}

void callback_rlen(const vesc_msgs::VescStateStamped::ConstPtr& msg)
{
    speed_rl.data = msg->state.speed;
    encoder_rl.data = (int)msg->state.distance_traveled;
    ROS_INFO("Data rear left sent");
    return;
}

void callback_rren(const vesc_msgs::VescStateStamped::ConstPtr& msg)
{
    speed_rr.data = msg->state.speed;
    encoder_rr.data = (int)msg->state.distance_traveled;
    ROS_INFO("Data rear right sent");
    return;
}

/* ------------------------------ Motor callback ------------------------------------*/
void callback_flmotor(const std_msgs::Float32::ConstPtr& msg)
{
    duty_cycle_fl.data = msg->data * VEL_TO_DUTY;    
    return;
}

void callback_frmotor(const std_msgs::Float32::ConstPtr& msg)
{
    duty_cycle_fr.data = msg->data * VEL_TO_DUTY * SIDEWAY_CALIB;
    return;
}

void callback_rlmotor(const std_msgs::Float32::ConstPtr& msg)
{
    duty_cycle_rl.data = msg->data * VEL_TO_DUTY;   
    return;
}

/* Because rear_right motor rotate slower than other at the same duty_cycle command, we need calib factor */
void callback_rrmotor(const std_msgs::Float32::ConstPtr& msg)
{
    duty_cycle_rr.data = msg->data * VEL_TO_DUTY * SIDEWAY_CALIB * RR_MOTOR_CALIB;
    return;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "vesc_converter");
    ros::NodeHandle n;

    std_msgs::Float64 starting_current;
    starting_current.data = 3;

    std_msgs::Float64 braking_current;
    braking_current.data = 3;

    std_msgs::Float64 normal_current;
    normal_current.data = 1;

    // Encoders
    pub_flen = n.advertise<std_msgs::Int64>("/flwheel", 10);
    pub_fren = n.advertise<std_msgs::Int64>("/frwheel", 10);
    pub_rlen = n.advertise<std_msgs::Int64>("/rlwheel", 10);
    pub_rren = n.advertise<std_msgs::Int64>("/rrwheel", 10);

    sub_flen = n.subscribe("/front_left/sensors/core", 10, callback_flen);
    sub_fren = n.subscribe("/front_right/sensors/core", 10, callback_fren);
    sub_rlen = n.subscribe("/rear_left/sensors/core", 10, callback_rlen);
    sub_rren = n.subscribe("/rear_right/sensors/core", 10, callback_rren);

    // Motors
    pub_flmotor = n.advertise<std_msgs::Float64>("/front_left/commands/motor/duty_cycle", 10);
    pub_frmotor = n.advertise<std_msgs::Float64>("/front_right/commands/motor/duty_cycle", 10);
    pub_rlmotor = n.advertise<std_msgs::Float64>("/rear_left/commands/motor/duty_cycle", 10);
    pub_rrmotor = n.advertise<std_msgs::Float64>("/rear_right/commands/motor/duty_cycle", 10);

    sub_flmotor = n.subscribe("/flwheel_vtarget", 10, callback_flmotor);
    sub_frmotor = n.subscribe("/frwheel_vtarget", 10, callback_frmotor);
    sub_rlmotor = n.subscribe("/rlwheel_vtarget", 10, callback_rlmotor);
    sub_rrmotor = n.subscribe("/rrwheel_vtarget", 10, callback_rrmotor);


    /*

    //Amp
    amp1 = n.advertise<std_msgs::Float64>("/left/commands/motor/current", 10);
    amp2 = n.advertise<std_msgs::Float64>("/right/commands/motor/current", 10);
    
    //Brake
    brake1 = n.advertise<std_msgs::Float64>("/left/commands/motor/brake", 10);
    brake2 = n.advertise<std_msgs::Float64>("/right/commands/motor/brake", 10);

    */

    while(ros::ok())
    {
        pub_flen.publish(encoder_fl);
        pub_fren.publish(encoder_fr);
        pub_rlen.publish(encoder_rl);
        pub_rren.publish(encoder_rr);
        pub_flmotor.publish(duty_cycle_fl);
        pub_frmotor.publish(duty_cycle_fr);
        pub_rlmotor.publish(duty_cycle_rl);
        pub_rrmotor.publish(duty_cycle_rr);
        ros::spinOnce();
    }
    
    return 0;
}
